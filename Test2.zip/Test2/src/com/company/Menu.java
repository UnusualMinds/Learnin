package com.company;

import java.util.ArrayList;

public class Menu {
    ArrayList<String> menu = new ArrayList<String>;
    void add(String str) {
        menu.add(str);
    }
}
