package com.company;
import org.json.simple.JSONObject;

public class User {
    String Name;
    Integer Age;
    String YearG;

    JSONObject toJson() {
        JSONObject out = new JSONObject();
        out.put("Name",Name);
        out.put("Age",Age);
        out.put("YearG",YearG);
        return out;
    }

}